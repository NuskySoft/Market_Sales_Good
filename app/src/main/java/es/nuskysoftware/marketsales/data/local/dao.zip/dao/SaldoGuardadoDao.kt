// app/src/main/java/es/nuskysoftware/marketsales/data/local/dao/SaldoGuardadoDao.kt
package es.nuskysoftware.marketsales.data.local.dao

import androidx.room.*
import es.nuskysoftware.marketsales.data.local.entity.SaldoGuardadoEntity

@Dao
interface SaldoGuardadoDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: SaldoGuardadoEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<SaldoGuardadoEntity>)

    @Query("""
        SELECT * FROM saldos_guardados 
        WHERE idUsuario = :userId AND consumido = 0 
        ORDER BY lastModified DESC 
        LIMIT 1
    """)
    suspend fun getUltimoNoConsumido(userId: String): SaldoGuardadoEntity?

    @Query("DELETE FROM saldos_guardados WHERE idRegistro = :id")
    suspend fun deleteById(id: String)

    @Query("""
        UPDATE saldos_guardados 
        SET consumido = 1, lastModified = :now, sincronizadoFirebase = 0 
        WHERE idRegistro = :id
    """)
    suspend fun marcarConsumido(id: String, now: Long = System.currentTimeMillis())

    @Query("SELECT * FROM saldos_guardados WHERE idUsuario = :userId ORDER BY lastModified DESC")
    suspend fun getAllByUser(userId: String): List<SaldoGuardadoEntity>
}



//// app/src/main/java/es/nuskysoftware/marketsales/data/local/dao/SaldoGuardadoDao.kt
//package es.nuskysoftware.marketsales.data.local.dao
//
//import androidx.room.*
//import es.nuskysoftware.marketsales.data.local.entity.SaldoGuardadoEntity
//import kotlinx.coroutines.flow.Flow
//
//@Dao
//interface SaldoGuardadoDao {
//
//    @Insert(onConflict = OnConflictStrategy.REPLACE)
//    suspend fun upsert(entity: SaldoGuardadoEntity)
//
//    @Query("DELETE FROM saldos_guardados WHERE idRegistro = :id")
//    suspend fun borrar(id: String)
//
//    @Query("DELETE FROM saldos_guardados WHERE idUsuario = :userId AND consumido = 0")
//    suspend fun borrarNoConsumidosDeUsuario(userId: String)
//
//    @Query("UPDATE saldos_guardados SET consumido = 1, version = version + 1, lastModified = :ts, sincronizadoFirebase = 0 WHERE idRegistro = :id")
//    suspend fun marcarConsumido(id: String, ts: Long = System.currentTimeMillis())
//
//    @Query("SELECT * FROM saldos_guardados WHERE idUsuario = :userId AND consumido = 0 ORDER BY lastModified DESC")
//    suspend fun getNoConsumidos(userId: String): List<SaldoGuardadoEntity>
//
//    @Query("SELECT * FROM saldos_guardados WHERE idUsuario = :userId ORDER BY lastModified DESC")
//    fun flowTodos(userId: String): Flow<List<SaldoGuardadoEntity>>
//
//    @Query("SELECT * FROM saldos_guardados WHERE idUsuario = :userId AND consumido = 0 ORDER BY lastModified DESC LIMIT 1")
//    suspend fun getUltimoNoConsumido(userId: String): SaldoGuardadoEntity?
//
//    // Helpers para sync
//    @Query("SELECT * FROM saldos_guardados WHERE idRegistro = :id LIMIT 1")
//    suspend fun getById(id: String): SaldoGuardadoEntity?
//
//    @Query("UPDATE saldos_guardados SET sincronizadoFirebase = 1 WHERE idRegistro = :id")
//    suspend fun marcarSincronizado(id: String)
//}
