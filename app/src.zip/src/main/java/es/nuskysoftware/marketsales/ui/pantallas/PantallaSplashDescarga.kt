package es.nuskysoftware.marketsales.ui.pantallas

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import es.nuskysoftware.marketsales.data.repository.MercadilloRepository
import es.nuskysoftware.marketsales.utils.ConfigurationManager

@Composable
fun PantallaSplashDescarga(
    navController: NavController
) {
    val context = LocalContext.current
    val repo = remember { MercadilloRepository(context) }

    // ✅ Descarga/merge si procede + autoestados + próximos mercadillos; después abrir "mercadillos"
    LaunchedEffect(Unit) {
        val userId = ConfigurationManager.getCurrentUserId()
        try {
            // Si no hay usuario válido (caso extraño), vamos directo
            if (userId.isNullOrBlank() || userId == "usuario_default") {
                navController.navigate("mercadillos") {
                    popUpTo("splash_descarga") { inclusive = true }
                    launchSingleTop = true
                }
                return@LaunchedEffect
            }

            // 1) Sincronizar (traer de Firebase si Room estaba vacío o había difs)
            try { repo.sincronizarSinEstadosAutomaticos() } catch (_: Exception) {}

            // 2) Actualizar estados automáticos
            try { repo.actualizarEstadosAutomaticos(userId) } catch (_: Exception) {}

            // 3) ✅ Llamada requerida: precalcular/precargar próximos mercadillos ANTES de abrir la lista
            try { repo.getMercadillosDesdeHoy(userId) } catch (_: Exception) {}

        } finally {
            navController.navigate("mercadillos") {
                popUpTo("splash_descarga") { inclusive = true }
                launchSingleTop = true
            }
        }
    }

    Surface(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        MaterialTheme.colorScheme.primary,
                        MaterialTheme.colorScheme.primaryContainer
                    )
                )
            )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Preparando tus datos…",
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onPrimary
                )
                CircularProgressIndicator(
                    modifier = Modifier.size(32.dp),
                    color = MaterialTheme.colorScheme.onPrimary
                )
                Text(
                    text = "Sincronizando y cargando próximos mercadillos",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f)
                )
            }
        }
    }
}
